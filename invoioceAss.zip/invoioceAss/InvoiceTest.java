package invoioceAss;
public class InvoiceTest {
    public static void main(String[] args) {
        // Create an Invoice object
        Invoice invoice = new Invoice("1234", "Hammer", 2, 14.95);

        // Display the invoice details
        System.out.println("Part Number: " + invoice.getPartNumber());
        System.out.println("Part Description: " + invoice.getPartDescription());
        System.out.println("Quantity: " + invoice.getQuantity());
        System.out.println("Price Per Item: $" + String.format("%.2f", invoice.getPricePerItem()));
        System.out.println("Invoice Amount: $" + String.format("%.2f", invoice.getInvoiceAmount()));

        // Modify the invoice details
        invoice.setQuantity(3);
        invoice.setPricePerItem(19.95);

        // Display the modified invoice details
        System.out.println("\nModified Invoice Details:");
        System.out.println("Part Number: " + invoice.getPartNumber());
        System.out.println("Part Description: " + invoice.getPartDescription());
        System.out.println("Quantity: " + invoice.getQuantity());
        System.out.println("Price Per Item: $" + String.format("%.2f", invoice.getPricePerItem()));
        System.out.println("Invoice Amount: $" + String.format("%.2f", invoice.getInvoiceAmount()));

        // Test invalid quantity and price
        invoice.setQuantity(-1);
        invoice.setPricePerItem(-10.0);

        // Display the invoice details after setting invalid values
        System.out.println("\nInvoice Details after setting invalid values:");
        System.out.println("Part Number: " + invoice.getPartNumber());
        System.out.println("Part Description: " + invoice.getPartDescription());
        System.out.println("Quantity: " + invoice.getQuantity());
        System.out.println("Price Per Item: $" + String.format("%.2f", invoice.getPricePerItem()));
        System.out.println("Invoice Amount: $" + String.format("%.2f", invoice.getInvoiceAmount()));
    }
}