package shape;
import shape.Box;
import shape.Circle;
import shape.Cylinder;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle(2);
		System.out.println("Area of Circle : "+c.calArea());
		Cylinder c1 = new Cylinder(3,4);
		System.out.println("Voume of Cylinder : "+c1.calVolume());
		Box b = new Box(5,6,7);
		System.out.println("Volume of Box : "+b.calVolume());
		

	}

}
