package test;

public class Program {
	 public static void main(String[] args) {
	        // Create a Date object
	        Date date = new Date(12, 25, 2022);

	        // Display the date
	        System.out.print("Initial date: ");
	        date.displayDate();

	        // Modify the date using set methods
	        date.setMonth(7);
	        date.setDay(4);
	        date.setYear(2023);

	        // Display the modified date
	        System.out.print("Modified date: ");
	        date.displayDate();

	        // Get and display individual date components
	        System.out.println("Month: " + date.getMonth());
	        System.out.println("Day: " + date.getDay());
	        System.out.println("Year: " + date.getYear());
	    }
	
}
